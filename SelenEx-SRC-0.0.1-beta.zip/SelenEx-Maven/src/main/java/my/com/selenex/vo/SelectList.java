package my.com.selenex.vo;

/**
 * 
 * @author Fa'izam
 *
 */
public class SelectList {

	public static final String value_annotation = "@value.";
	public static final String text_annotation = "@text.";
	public static final String index_annotation = "@index";

}
